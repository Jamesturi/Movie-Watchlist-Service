// src/setupProxy.js
console.log('🛠 setupProxy.js loaded');
const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:5000',
      changeOrigin: true,
      logLevel: 'debug',               // ← show every request and error
      onProxyReq(proxyReq, req, res) {
        console.log(
          `[HPM] proxying request ${req.method} ${req.url}`
        );
      },
      onError(err, req, res) {
        console.error('[HPM] proxy error:', err);
      }
    })
  );
};
