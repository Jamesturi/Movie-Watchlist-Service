// client/src/components/layout/Spinner.js

import React from 'react';

const Spinner = () => (
  <div>
    <div className="spinner" />
  </div>
);

export default Spinner;
