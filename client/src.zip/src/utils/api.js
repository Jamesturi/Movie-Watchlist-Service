// client/src/utils/api.js
import axios from 'axios';

// Determine the base URL based on environment
const getBaseUrl = () => {
  // In production, use the deployed API URL
  if (process.env.NODE_ENV === 'production') {
    return process.env.REACT_APP_API_URL || 'https://api.moviewatchlist.com';
  }
  
  // In development, if we're using the proxy in package.json, we can use relative URLs
  if (process.env.REACT_APP_USE_PROXY === 'true') {
    return '';
  }
  
  // Default fallback for development without proxy
  return 'http://localhost:5000';
};

// Create the Axios instance with proper configuration
const api = axios.create({
  baseURL: getBaseUrl(),
  headers: {
    'Content-Type': 'application/json',
  },
  // Ensure cookies are sent with requests if using cookie-based auth
  withCredentials: false, // Set to true if using cookies for auth
});

// Request interceptor for adding auth token
api.interceptors.request.use(
  (config) => {
    // Get token from localStorage
    const token = localStorage.getItem('token');
    
    // If token exists, add it to the headers
    if (token) {
      // Important: Create a new headers object to avoid mutation issues
      config.headers = {
        ...config.headers,
        Authorization: `Bearer ${token}`,
      };
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for handling common errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle session expiration (401 errors)
    if (error.response && error.response.status === 401) {
      // Clear auth state
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      
      // Redirect to login if not already there
      if (window.location.pathname !== '/login') {
        window.location.href = '/login?session=expired';
      }
    }
    
    // Network errors - likely CORS or server down
    if (error.message === 'Network Error') {
      console.error('Network error detected. Possible CORS issue or server is down.');
    }
    
    return Promise.reject(error);
  }
);

export default api;