// client/src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/auth/AuthContext';

import Navbar from './components/layout/Navbar';
import Home from './components/pages/Home';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Dashboard from './components/pages/Dashboard';
import PrivateRoute from './components/routing/PrivateRoute';
import ApiDiagnostic from './components/ApiDiagnostic';

import './App.css';

const App = () => (
  <AuthProvider>
    <Router>
      <Navbar />
      <div className="container">
        <Routes>
          {/* Public routes */}
          <Route path="/"       element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login"  element={<Login />} />

          {/* Protected routes wrapper */}
          <Route element={<PrivateRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/api-test"  element={<ApiDiagnostic />} />
          </Route>
        </Routes>
      </div>
    </Router>
  </AuthProvider>
);

export default App;
